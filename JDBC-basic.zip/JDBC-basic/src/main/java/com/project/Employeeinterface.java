package com.project;

import java.sql.Connection;

public interface Employeeinterface {
	
	public Connection getDbConnection();
	public void createTable();
	public void insertEmployee();
	public void removeEmployee();
	public void removeallEmployee();
	public void displayEmployee();
	public void displayAllEmployee();
	public void updateEmployee();
	public void countEmployee();
	public void sortEmployee();
	public void findEmployeehighestsal();
	public void findEmployeelowesrsal();
	

}
