package com.project;

import java.util.Scanner;

public class Driver {
	public static void main(String[] args) {
		
		Employeeinterface emp=new Employeeimplentsclass();
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to Employee Databse");
		System.out.println("1.CREATE\n2.INSERT\n3.REMOVE\n4.REMOVE ALL\n5.2DISPLAY\n6.DISPLAY ALL\n7.UPDATE\n8.COUNT\n9.SORT\n10.FIND HISHEST SALARY\n11.FIND LOWEST SALARY");
		System.out.println("Enter your choice");
		int option=sc.nextInt();
		switch(option) {
		case 1:
			emp.createTable();
			break;
		case 2:
			emp.insertEmployee();
			break;
		case 3:
			emp.removeEmployee();
			break;
		case 4:
			emp.removeallEmployee();
			break;
		case 5:
			emp.displayEmployee();
			break;
		case 6:
			emp.displayAllEmployee();
			break;
		case 7:
			emp.updateEmployee();
			break;
		case 8:
			emp.countEmployee();
			break;
		case 9:emp.sortEmployee();
			break;
		case 10:
			emp.findEmployeehighestsal();
			break;
		case 11:
			emp.findEmployeelowesrsal();
			break;
		}
		
	}

}
