package com.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Employeeimplentsclass implements Employeeinterface{

	public Connection getDbConnection() {
		// TODO Auto-generated method stub
		
		String url="jdbc:mysql://localhost:3306/jdbc-3-schema";
		String user="root";
		String password="root";
		Connection con=null;
		
		try {
			con=DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}

	public void createTable() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		try {
			Statement state=con.createStatement();
			String query="CREATE TABLE employee (id INT PRIMARY KEY,name VARCHAR(25),salary DECIMAL(10,2),address VARCHAR(25),email VARCHAR(25))";
			state.execute(query);
			con.close();
			System.out.println("Table created");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void insertEmployee() {
		// TODO Auto-generated method stub
		Connection con=getDbConnection();
		String query="INSERT INTO employee VALUES(?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			Scanner sc=new Scanner (System.in);
			System.out.println("Enter the values to enter");
			int id=sc.nextInt();
			String name=sc.next();
			Double salary=sc.nextDouble();
			String address=sc.next();
			String email=sc.next();
			
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setDouble(3, salary);
			ps.setString(4, address);
			ps.setString(5, email);
			
			ps.execute();
			con.close();
			System.out.println("Inserted Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void removeEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="DELETE FROM employee WHERE ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			Scanner sc=new Scanner (System.in);
			System.out.println("Enter the id which you want to delete");
			int id=sc.nextInt();
	
			
			ps.setInt(1, id);
			
			ps.execute();
			con.close();
			System.out.println("Removes Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void removeallEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="DELETE FROM employee";
		try {
			
			Statement state=con.createStatement();
			state.execute(query);
			con.close();
			System.out.println("Removed Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void displayEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="SELECT * FROM employee WHERE ID=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			Scanner sc=new Scanner (System.in);
			System.out.println("Enter the id which you want to display");
			int id=sc.nextInt();
	
			ps.setInt(1, id);
			ps.execute();
			
			ResultSet rs=ps.getResultSet();
			rs.next();
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getDouble(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getString(5));
			
			
			con.close();
			System.out.println("Displyed Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void displayAllEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="SELECT * FROM employee";
		try {
			Statement state=con.createStatement();
			state.execute(query);
			
			ResultSet rs=state.getResultSet();
			while(rs.next()) {
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getDouble(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getString(5));
			}
			
			con.close();
			System.out.println("Displyed Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public void updateEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="UPDATE employee SET email=? WHERE id=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			Scanner sc=new Scanner (System.in);
			System.out.println("Enter the email to change");
			String email=sc.next();
			System.out.println("enter the id which want the email to be changed");
			int id=sc.nextInt();
			
			ps.setString(1, email);
			ps.setInt(2, id);
			
			ps.execute();
			con.close();
			System.out.println("Updated Sucessfully Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public void countEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="SELECT COUNT(*) FROM employee";
		try {
			Statement state=con.createStatement();
			state.execute(query);
			
			ResultSet rs=state.getResultSet();
			while(rs.next()) {
			System.out.println(rs.getInt(1));

			}
			
			con.close();
			System.out.println("Displyed count Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	public void sortEmployee() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="SELECT * FROM employee ORDER BY name";
		try {
			Statement state=con.createStatement();
			state.execute(query);
			
			ResultSet rs=state.getResultSet();
			while(rs.next()) {
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getDouble(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getString(5));
			}
			
			con.close();
			System.out.println("Sorted  Data Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void findEmployeehighestsal() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="SELECT * FROM employee WHERE salary = (SELECT MAX(salary) FROM employee)";
		try {
			Statement state=con.createStatement();
			state.execute(query);
	

			ResultSet rs=state.getResultSet();
			rs.next();
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getDouble(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getString(5));
			
			
			con.close();
			System.out.println("Displyed employee with highest Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void findEmployeelowesrsal() {
		// TODO Auto-generated method stub
		
		Connection con=getDbConnection();
		String query="SELECT * FROM employee WHERE salary = (SELECT MIN(salary) FROM employee)";
		try {
			Statement state=con.createStatement();
			state.execute(query);
	

			ResultSet rs=state.getResultSet();
			System.out.println(rs.getInt(1));
			System.out.println(rs.getString(2));
			System.out.println(rs.getDouble(3));
			System.out.println(rs.getString(4));
			System.out.println(rs.getString(5));
			
			
			con.close();
			System.out.println("Displyed employee with Lowest Succesfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
