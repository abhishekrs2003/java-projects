package person_aadhaar_springboot;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class PersonController {

    @Autowired
    PersonRepo personRepo;

    @Autowired
    AdaarRepo aadhaarRepo;


    @PostMapping("/saveperson/{aadhaarId}")
    public String addPerson(@RequestBody Person person, @PathVariable int aadhaarId) {
        Optional<Adaar> optionalAadhaar = aadhaarRepo.findById(aadhaarId);
        if (optionalAadhaar.isPresent()) {
            Adaar aadhaar = optionalAadhaar.get();
            person.setAadhaar(aadhaar);
        } else {
            person.setAadhaar(null);
        }
        personRepo.save(person);
        return "person data saved succesfully";


    }
    
    @PutMapping("/updateperson/{aadhaarId}")
    public String updatePerson( @PathVariable int aadhaarId, @RequestBody Person person) {
        Optional<Adaar> optionalAadhaar = aadhaarRepo.findById(aadhaarId);
        if (optionalAadhaar.isPresent()) {
            Adaar aadhaar = optionalAadhaar.get();
            person.setAadhaar(aadhaar);
        } else {
            person.setAadhaar(null);
        }

        personRepo.save(person);
        return "person data updated sucessfully";

    }


    @GetMapping("/getallperson")
    public List<Person> getAllPersons() {
        return personRepo.findAll();
    }


    @GetMapping("/getpersonbyid/{id}")
    public Person getPerson(@PathVariable int id) {
        Optional<Person> p = personRepo.findById(id);
        if (p.isPresent()) {
            return p.get();
        } else {
            return null;
        }

    }


    @DeleteMapping("/deletebyidperson/{id}")
    public String deletePerson(@PathVariable int id) {
        personRepo.deleteById(id);
        return "Person deleted with id: " + id;
    }
}