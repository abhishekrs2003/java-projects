package person_aadhaar_springboot;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class AdaarController {

    @Autowired
    AdaarRepo aadhaarRepo;


    @PostMapping("/saveadaar")
    public String addAadhaar(@RequestBody Adaar aadhaar) {
        aadhaarRepo.save(aadhaar);
        return "data added successfully";
    }


    @PutMapping("/updateadaar")
    public String updateAadhaar(@RequestBody Adaar aadhaar) {
    	aadhaarRepo.save(aadhaar);
    	return "data updated sucessfully";
    }
 
    @GetMapping("/getalldata")
    public List<Adaar> getAllAadhaar() {
        return aadhaarRepo.findAll();
    }

 
    @GetMapping("/findadaarbyid/{id}")
    public Adaar getAadhaar(@PathVariable int id) {
        Optional<Adaar> a = aadhaarRepo.findById(id);
        if (a.isPresent()) {
            return a.get();
        } else {
            return null;
        }
    }

    @DeleteMapping("/deletebyid/{id}")
    public String deleteAadhaar(@PathVariable int id) {
        aadhaarRepo.deleteById(id);
        return "Aadhaar deleted with id: " + id;
    }
}