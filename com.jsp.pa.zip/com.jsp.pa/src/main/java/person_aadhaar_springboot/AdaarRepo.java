package person_aadhaar_springboot;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AdaarRepo extends JpaRepository<Adaar, Integer>{

}
